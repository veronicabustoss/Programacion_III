<?php

//Traer todos usuarios
//Declaramos el post de que hago para poder controlar el switch
$queHago = isset($_POST['queHago']) ? $_POST['queHago'] : NULL;

//Declaramos las variables para poder conectarnos en sql
$host = "localhost";
$user = "root";
$pass = "";
$base = "mercado";

//Recuperamos valores por POST
//Hay que setear los nombres como el $queHago y el null vendria a ser un else
///********USUARIOS******** */
$nombre = isset($_POST["nombre"]) ? $_POST["nombre"] : NULL;
$apellido = $_POST["apellido"];
$clave =  $_POST["clave"];
$perfil = $_POST["perfil"];
$estado = $_POST["estado"];
$id = $_POST["id"];

/****************PRODUCTOS************/
$idProducto = isset($_POST["idProducto"]) ? $_POST["idProducto"] : NULL;
$codBarraProducto = isset($_POST["codBarraProducto"]) ? $_POST["codBarraProducto"] : NULL;
$nombreProducto = isset($_POST["nombreProducto"]) ? $_POST["nombreProducto"] : NULL;
$pathProducto = isset($_POST["pathProducto"]) ? $_POST["pathProducto"] : NULL;

//Primero conectamos a la base de datos
$con = @mysqli_connect($host, $user, $pass,$base);

//Comprobamos que haya tenido exito la conexion
if(!$con)
{
    echo "errno de depuración: " . mysqli_connect_errno() . PHP_EOL;
    echo "error: " . mysqli_connect_error() . PHP_EOL . "</pre>";
    return;
}

//
switch($queHago)
{
    case"traerTodos_usuarios":
    
    $sql = "SELECT * FROM usuarios";
    $rs = $con->query($sql);
    while ($row = $rs->fetch_object()){ //fetch_all / fetch_assoc / fetch_array([MYSQLI_NUM | MYSQLI_ASSOC | MYSQLI_BOTH])
        $user_arr[] = $row;
    }  
    var_dump($user_arr); 
    mysqli_close($con);
        ///Colspan, donde no haya usuarios
    ///Crear una fila por cada usuario que tenga
    $tabla = "
                <table border='1'>
                    <tr>
                        <td>Id</td>
                        <td>Nombre</td>
                        <td>Apellido</td>
                        <td>Perfil</td>
                        <td>Estado</td>
                    </tr>
    ";

    //while($i = 0; $i < )
    //Si no hay ningun usuario
    //$tabla .= "<tr><td colspan>sin usuarios</tr>";
    break;
    
    case "traerPorId_usuarios":
    $sql = "SELECT * FROM `usuarios` WHERE id=2";
    $rs = $con->query($sql);
    while ($row = $rs->fetch_object()){ //fetch_all / fetch_assoc / fetch_array([MYSQLI_NUM | MYSQLI_ASSOC | MYSQLI_BOTH])
        $user_arr[] = $row;
    }  
    var_dump($user_arr); 
    mysqli_close($con);

    break;
    
    case"traerPorEstado_usuarios":
    
    $sql = "SELECT * FROM `usuarios` WHERE estado=6";
    $rs = $con->query($sql);
    while ($row = $rs->fetch_object()){ //fetch_all / fetch_assoc / fetch_array([MYSQLI_NUM | MYSQLI_ASSOC | MYSQLI_BOTH])
        $user_arr[] = $row;
    }  
    var_dump($user_arr); 
    mysqli_close($con);
    break;
    
    case "agregar_usuarios":

    $sql = "INSERT INTO `usuarios`(`nombre`, `apellido`, `clave`, `perfil`, `estado`) 
            VALUES ('$nombre','$apellido','$clave',$perfil,$estado)";
    
    var_dump($sql);
    $rs = $con->query($sql);
    echo "<pre>Filas afectadas: " . mysqli_affected_rows($con) . "<br>mysqli_affected_rows(con)</pre>";  
    echo "Usuario creado con exito!";
    mysqli_close($con);

    break;

    case "modificar_usuarios":
        
        $sql = "UPDATE `usuarios` SET `nombre`='$nombre',`apellido`='$apellido',`clave`='$clave',`perfil`='$perfil',`estado`='$estado' WHERE id='4'";
        
        $rs = $con->query($sql);
        echo "<pre>Filas afectadas: " . mysqli_affected_rows($con) . "<br>mysqli_affected_rows(con)</pre>";  
        echo "Usuario modificado con exito!";
        
        break;

        case "borrar_usuarios":

        $sql = "DELETE FROM `usuarios` WHERE id='$id'";
        $rs = $con->query($sql);
        echo "<pre>Filas afectadas: " . mysqli_affected_rows($con) . "<br>mysqli_affected_rows(con)</pre>";  
        echo "Usuario borrado con exito!";
        
        break;
        
    case "traerTodos_productos":
            $sql = "SELECT * FROM `productos` WHERE 1";
            $rs = $con->query($sql);
            while ($row = $rs->fetch_object()){ //fetch_all / fetch_assoc / fetch_array([MYSQLI_NUM | MYSQLI_ASSOC | MYSQLI_BOTH])
                $user_arr[] = $row;
            }  
            var_dump($user_arr); 
            mysqli_close($con);
        break;
    case "traerPorId_productos":
            $sql = "SELECT * FROM `productos` WHERE id='$idProducto'";
            $rs = $con->query($sql);
            while ($row = $rs->fetch_object()){ //fetch_all / fetch_assoc / fetch_array([MYSQLI_NUM | MYSQLI_ASSOC | MYSQLI_BOTH])
                $user_arr[] = $row;
            }  
            var_dump($user_arr); 
            mysqli_close($con);
        break;
    case "agregar_productos":
    
            $sql = "INSERT INTO `productos`(`codigo_barra`, `nombre`, `path_foto`) VALUES ('$codBarraProducto','$nombreProducto','$pathProducto')";
    
            var_dump($sql);
            $rs = $con->query($sql);
            echo "<pre>Filas afectadas: " . mysqli_affected_rows($con) . "<br>mysqli_affected_rows(con)</pre>";  
            echo "Producto creado con exito!";
            mysqli_close($con);
        break;
    case "modificar_productos":
        
        $sql = "UPDATE `productos` SET `codigo_barra`='$codBarraProducto',`nombre`='$nombreProducto',`path_foto`='$pathProducto' WHERE id='$idProducto' ";
        var_dump($sql);
        $rs = $con->query($sql);
        echo "<pre>Filas afectadas: " . mysqli_affected_rows($con) . "<br>mysqli_affected_rows(con)</pre>";  
        echo "Producto modificado con exito!";
        mysqli_close($con);
        break;
    case "eliminar_productos":

        $sql = "DELETE FROM `productos` WHERE id=$idProducto";
        var_dump($sql);
        $rs = $con->query($sql);
        echo "<pre>Filas afectadas: " . mysqli_affected_rows($con) . "<br>mysqli_affected_rows(con)</pre>";  
        echo "Producto eliminado con exito!";
        mysqli_close($con);
        break;
    
    default:
        echo "Error";
    
    
}

?>