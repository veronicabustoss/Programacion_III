<?php
require_once "AccesoDatos.php";
require_once "IParte2.php";

class Producto implements IParte2
{
    public $codigoBarra;
    public $descripcion;
    public $precio;
    public $pathFoto;

    public function __construct($codigoBarra = null, $descripcion = null,$precio = null, $pathFoto = null)
    {
        $this->codigoBarra = $codigoBarra!=null ? $codigoBarra : "";
        $this->descripcion = $descripcion!=null ? $descripcion : "";
        $this->precio = $precio!=null ? $precio : "";
        $this->pathFoto = $pathFoto!=null ? $pathFoto : "";
    }

    public function ToJSON()
    {
        //Retorna una cadena con formato Json
        return '{"codigo_barra": '. $this->codigoBarra . ', "descripcion": "'. $this->descripcion . '", "precio": '. $this->precio . ', "foto": "'. $this->pathFoto . '"}';  
    }

    public function Agregar()
    {
        $objPdo = AccesoDatos::DameUnObjetoAcceso();
        $consulta = $objPdo->RetornarConsulta("INSERT INTO productos(codigo_barra,descripcion,precio,foto)"
                                                . "VALUES(:codigo_barra, :descripcion, :precio, :foto)"); 
        $consulta->bindValue(':codigo_barra',$this->codigoBarra,PDO::PARAM_INT);
        $consulta->bindValue(':descripcion',$this->descripcion,PDO::PARAM_STR);
        $consulta->bindValue(':precio',$this->precio);
        $consulta->bindValue(':foto',$this->pathFoto,PDO::PARAM_STR);
        return $consulta->execute();

    }

    public function Traer()
    {       
        $objPdo = AccesoDatos::DameUnObjetoAcceso();
        $consulta = $objPdo->RetornarConsulta("SELECT * FROM productos WHERE 1");
        $consulta->execute();

        $consulta->setFetchMode(PDO::FETCH_INTO, new Producto); 
        $arrayAux = array();
        foreach($consulta as $pro)
        {
            $auxTele = new Producto($pro->codigo_barra,$pro->descripcion,$pro->precio,$pro->foto);
            array_push($arrayAux,$auxTele);
            
        }   
        return $arrayAux;
    }

    public function CalcularIVA()
    {
        return $this->precio * 0.21;
    }

    public function Existe($arPro)
    {
        $retorno = false;
        foreach($arPro as $prod)
        {
            if($prod->ToJSON() == $this->ToJSON())
            {
                $retorno = true;
                break;
            }
        }
        return $retorno;
    }

    public function Modificar($id)
    {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
            
        $consulta =$objetoAccesoDato->RetornarConsulta("UPDATE ovnis SET codigo_barra=:codigo_barra,descripcion=:descripcion,precio=:precio,foto=:foto WHERE id=:id");
        
        $consulta->bindValue(':codigo_barra',$this->codigoBarra,PDO::PARAM_INT);
        $consulta->bindValue(':descripcion',$this->descripcion,PDO::PARAM_STR);
        $consulta->bindValue(':precio',$this->precio);
        $consulta->bindValue(':foto',$this->pathFoto,PDO::PARAM_STR);
        $consulta->bindValue(':id',$id,PDO::PARAM_INT);
        $flag = false;
        $consulta->execute();
        if($consulta->rowCount() > 0) 
        {
            $flag = true;
        }
       
         return $flag;
    }

    public function Eliminar($id)
    {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
            
        $consulta =$objetoAccesoDato->RetornarConsulta("DELETE FROM productos WHERE id=:id");

        $consulta->bindValue(':id',$id,PDO::PARAM_INT);
        $flag = false;
        $consulta->execute();
        if($consulta->rowCount() > 0) 
        {
            $flag = true;
        }
       
         return $flag;
    }




}


?>