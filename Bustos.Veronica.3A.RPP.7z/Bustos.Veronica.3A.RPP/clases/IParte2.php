<?php

interface IParte2
{
    public function Agregar();
    public function Traer();
    public function CalcularIVA();
    public function Existe($arOvni);
    public function Eliminar($id);
    public function Modificar($id);
}

?>