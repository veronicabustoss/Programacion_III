<?php

require_once "./clases/Producto.php";

$producto = new Producto();

$listado = $producto->Traer();

$tabla = ("<table align='center' border='1'
            <tr>
            <th>CODIGO_BARRA</th>
            <th>DESCRIPCION</th>
            <th>PRECIO</th>
            <th>FOTO</th>
            <th>IVA</th>
            </tr>
            ");

foreach($listado as $obj)
{   
                $tabla.= "<tr>
                            <td>" . $obj->codigo_barra . "</td>
                             <td>" . $obj->descripcion . "</td>
                             <td>" . $obj->precio . "</td>";

                if($obj->pathFoto != null)
                {
                    $tabla .= "<td><img src='" . $obj->pathFoto . "' width=100></td>";
                }
                else{
                    $tabla.= "<td></td>";
                }
                $tabla.= "<td>". $obj->CalcularIVA() ."</td>
                     </tr>";
}

$tabla .="</table>";

echo $tabla;

?>