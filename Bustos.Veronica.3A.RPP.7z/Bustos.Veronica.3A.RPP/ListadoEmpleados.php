<?php
require_once "./clases/Empleado.php";

$lista = Empleado::TraerTodos();
$cadena = array();
foreach($lista as $emp)
{
    array_push($cadena,$emp->ToJSON());
}

echo json_encode($cadena);
?>