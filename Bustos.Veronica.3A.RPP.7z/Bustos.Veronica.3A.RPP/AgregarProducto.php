<?php

require_once "./clases/Producto.php";

$json = isset($_POST['json']) ? $_POST['json'] : NULL;

$foto = isset($_FILES["foto"]["name"]) ? $_FILES["foto"]["name"] : null;

$decodeo = json_decode($json);

$nombreFoto = $decodeo->codigo_barra . "." . $decodeo->descripcion. "." . date("Gis") . ".jpg";
$ruta = "./productos/imagenes/".$nombreFoto;

$producto = new Producto($decodeo->codigoBarra,$decodeo->descripcion,$decodeo->precio,$ruta);

$json = new stdClass();
$json->exito = false;

if(move_uploaded_file($_FILES["foto"]["tmp_name"],$ruta))
{
    if($producto->Agregar()){
        $json->exito = true;
        $json->mensaje = "Se agrego correctamente";
        header('location: Listado.php');
    }
    else{
        $json->mensaje = "No se pudo agregar";
        echo json_encode($json);
    }
}



?>