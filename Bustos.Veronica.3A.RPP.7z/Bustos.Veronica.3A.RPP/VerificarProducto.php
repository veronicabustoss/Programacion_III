<?php

require_once "./clases/Producto.php";

$jsonPro = isset($_POST['json']) ?$_POST['json'] : NULL;

$decodeo = json_decode($json);

$producto = new Producto($decodeo->codigoBarra,$decodeo->descripcion,$decodeo->precio,$ruta);

$listado = $producto->Traer();

$retorno = "No existe ese Producto.";


if($producto->Existe($listado))
{
    $retorno = $producto->ToJSON();
}

echo $retorno

?>