<?php
require_once './clases/Producto.php';
//require_once "./clases/Ufologo.php";

$id = isset($_POST['id']) ? $_POST['id'] : null;
$tipo = isset($_POST['tipo']) ? $_POST['tipo'] : null;
$velocidad = isset($_POST['velocidad']) ? $_POST['velocidad'] : null;
$planeta = isset($_POST['planetaOrigen']) ? $_POST['planetaOrigen'] : null;
$foto = isset($_FILES["foto"]["name"]) ? $_FILES["foto"]["name"] : null;

$nombreFoto = $tipo . "." . $planeta. ".modificado." . date("Gis") . ".jpg";
$ruta = "./ovnisModificados/".$nombreFoto;

$ovni = new Ovni($tipo,$velocidad,$planeta,$ruta);

$seModifico = $ovni->Modificar($id);

if($seModifico)
{
    //$ruta = "./ovnisModificados/".$nombreFoto;
    if(move_uploaded_file($_FILES["foto"]["tmp_name"],$ruta))
    {
        header('location:ListadoUfologo.php');
    }

}
else
{
    $stdClass = new stdClass();
    $stdClass->exito = false;
    $stdClass->mensaje ="El ovni no se pudo modificar!.";
    echo json_encode($stdClass);
}

?>
