<?php
//ABRO ARCHIVO
    $archivo = fopen("Greetings.txt", "r+");

    //echo "<h3>" . fread($archivo, filesize("Greetings.txt")) . "</h3>";

    while(!feof($archivo)){
        echo "<h3>" . fgets($archivo) . "</hr3>";
        echo "<br>";
    }
//CIERRO ARCHIVO

/**
 * MORE COMMENTARIES
 */
    fclose($archivo);
?>