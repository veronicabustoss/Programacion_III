<?php
    /*$archivo = fopen("Greetings.txt", "a");

    //fwrite($archivo,"Hello, darling <3\r\n");
    //fwrite($archivo,"My name is Kanon\r\n");
    //fwrite($archivo,"Nice to meet you!\r\n");

    $name = $_POST["name"];
    $lastName = $_POST["lastName"];

    fwrite($archivo, $name ."\r\n");
    fwrite($archivo, $lastName ."\r\n");
    fclose($archivo);

    */

    var_dump($_FILES);

?>