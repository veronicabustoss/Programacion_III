<?php
require ".\Clases\Producto.php";
require ".\Clases\Archivo.php";
    $option = "MOSTRAR";
    
    switch ($option) {
        case 'ALTA':
            //$producto = new Producto("Bic", "123456789");
            $archivo = new Archivo();
            if($archivo::Subir() == TRUE)
            {
                $producto = new Producto($_POST["name"], $_POST["cod_barra"] ,"/Archivos/".$_FILES["ttt"]["name"]);
                if($producto::Guardar($producto)){
                    echo "Saved Suscesfully";
                }else{
                    echo "Error Saving File";
                }
                break;
            }

        case 'MOSTRAR':
           // $producto = new Producto("Bic", "123456789");
            //$producto->LoadProducts();
            $producto = new Producto($_POST["name"], $_POST["cod_barra"] ,"/Archivos/".$_FILES["ttt"]["name"]);
            echo "<br>LISTA DE PRODUCTOS:<br>";
            foreach(Producto::LoadProducts() as $producto)
            {
                echo($producto->ToString());
                echo("<img src='./".$producto->path_foto . "' width=50 heigth=50>");
                echo("<br>");
            }
            break;
        
        default:

            break;
    }

?>