<?php
class Producto{
    private $nombre;
    private $cod_barra;
    public $path_foto;

    public function __construct($n=null, $c=null,$p=null){
        if($n!=null && $c!=null && $p!=null){
            $this->nombre = $n;
            $this->cod_barra = $c;
            $this->path_foto= $p;
        }

    }

    public function ToString(){
        return $this->cod_barra . " - " . $this->nombre . " - ".$this->path_foto. "\r\n";
    }

    //devuelve un booleano
    public static function Guardar($obj){
        $result = false;
        $archivo = fopen("./Archivos/productos.txt", "a+");
        
        if(fwrite($archivo, $obj->ToString()) >0 )
        $result = true;

        fclose($archivo);
        return $result;
    }

    //devuelve un array de tipo producto
    public static function LoadProducts(){
        $archivo = fopen("./Archivos/productos.txt", "r+");
        $array = array();
        while(!feof($archivo)){
            $a = explode(" - ", fgets($archivo));
            if(isset($a[1]))//Si existe la variable 1 
            {
                    $producto = new Producto($a[0],$a[1],$a[2]);
                    array_push($array, $producto);

            }


        }

        fclose($archivo);
        return $array;
    }
}


?>