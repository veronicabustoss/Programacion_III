<?php


class archivo
{
    public function Subir()
    {
        $origen = $_FILES["ttt"]["tmp_name"];
        $destino = "../ABM productos/Archivos/" . $_FILES["ttt"]["name"];
        $seSubio = TRUE;

        if(file_exists($destino) == FALSE)
        {
            move_uploaded_file($origen,$destino);
            echo("El". $origen. " se subio correctamente.");
            echo "<br>";
        }
        else
        {
            echo "El archivo existe.";
            $seSubio = FALSE;
        } 

        return $seSubio;
        /*
        if($_FILES["archivo"]["size"] > 100000)
        {
            echo "El archivo es demasiado grande.";
            $seSubio =  TRUE;
        }

        //var_dump(getimagesize($_FILES["archivo"]["tmp_name"]));

        $esImagen = getimagesize($_FILES["archivo"]["tmp_name"]);

        if($esImagen === TRUE)
        {
            if($tipoArchivo != "jpg" && $tipoArchivo != "jpeg" && $tipoArchivo != "gif"
		&& $tipoArchivo != "png") {
		echo "Solo son permitidas imagenes con extension JPG, JPEG, PNG o GIF.";
        $uploadOk = FALSE;
        }
        else
        {
        echo "El archivo no es una imagen!!!";
        $seSubio = FALSE;
      }



        if($seSubio == TRUE)
           {
        echo "El archivo que subio con exito";
         }
    else
    {
    echo "El archivo no se pudo subir :(";
    }

    //Si pude subir la imagen, muestro el exito, de lo contrario error
    //true archivos
   
    //false 

	}
*/
    }
}


?>