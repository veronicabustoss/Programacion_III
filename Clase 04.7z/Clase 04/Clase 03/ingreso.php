<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <form action="writer.php" method="post" enctype="multipart/form-data">
    <table align="center">
            <tr>
                <td>Name</td>
            </tr>
            <tr>
                <td>
                    <input type="text" name="name" id="name">
                </td>
            </tr>
            <tr>
                <td>LastName</td>
                </tr>
                <tr>
                <td>
                    <input type="text" name="lastName" id="lastName">
                </td>
            </tr>
            <tr>
                <td>
                    <input type="submit" name="Send">
                </td>
            </tr>
            <tr>
                <td>
                    <input type="reset" name="Send">
                </td>
            </tr>
                 <tr>
                     <td> Subir foto:</td>
                 </tr>
            <tr>

            <td>
                <input type="file" name="ttt">
            </td>
            
            </tr>
        </table>
    </form>
</body>
</html>