<?php

require_once 'Usuario.php';

class MW
{
    public function VerificarSeteo($request, $response, $next)
    {
        $ArrayDeParametros = $request->getParsedBody();
        $correo = $ArrayDeParametros['correo'];
        $clave = $ArrayDeParametros['clave'];

        if(isset($correo) || isset($clave))
        {
            $newResponse = $next($request, $response);

        }
        else
        {
            
            $std = new stdClass();
            $std->mensaje = "Los campos de correo o clave no estan seteados";
            $newResponse = $response->withJson($std,409);
        }

        return $newResponse;
    }

    public static function VerificarVacio($request, $response, $next)
    {
        $ArrayDeParametros = $request->getParsedBody();
        $correo = $ArrayDeParametros['correo'];
        $clave = $ArrayDeParametros['clave'];   

        if($clave == null || $correo == null)
        {
            $std = new stdClass();
            $std->mensaje = "Los campos de correo o clave estan vacios.";
            $newResponse = $response->withJson($std,409);

        }
        else
        {
            $newResponse = $next($request, $response);
        }

        return $newResponse;
    }

    public function VerificarExistencia($request, $response, $next)
    {
        $ArrayDeParametros = $request->getParsedBody();
        $correo = $ArrayDeParametros['correo'];
        $clave = $ArrayDeParametros['clave'];

        $obj = Usuario::ExisteEnBD($correo,$clave);
        if($obj->existe != true)
        {
            $std = new stdClass();
            $std->mensaje = "El correo y clave NO se encuentra en la base de datos";
            $newResponse = $response->withJson($std,409);   
        }
        else
        {
            $newResponse = $next($request, $response);
        }

        return $newResponse;
    }

    public function VerificarToken($request, $response, $next)
    {
        $token = null;
        if($request->IsGet())
        {
            $token = $_GET["token"];
        }
        else
        {
            $token = $request->getParsedBody()["token"];
            
        }
        $obj = Usuario::VerificarJWT($token);
        
        if($obj->status === 403)
        {
            $retorno = new StdClass();
            $retorno->mensaje = "ERROR: Token invalido";
            $retorno->exito = false;
            $newResponse = $response->withJson($retorno, 403);
        }
        else
        {
            $newResponse = $next($request, $response);
        }
        return $newResponse;
    }

    public function VerificarEncargadoYPropietario($request, $response, $next)
    {
        $token = null;
        if($request->IsGet())
        {
            $token = $_GET["token"];
        }
        else
        {
            $token = $request->getParsedBody()["token"];
        }
        $obj = Usuario::VerificarJWT($token);
        $usuario = $obj->payload;
         $retorno = new StdClass();

        if($usuario->perfil == "encargado" || $usuario->perfil=="Encargado" )
        {
            $retorno->mensaje = "El usuario es un encargado!!";
            $retorno->exito = true;
            $newResponse = $next($request, $response);
        }
        else if($usuario->perfil == "propietario" || $usuario->perfil=="Propietario")
        {
            $retorno->mensaje = "El usuario es un propietario!!";
            $retorno->exito = true;
            $newResponse = $next($request, $response);
            
        }
        else
        {
            $retorno->mensaje = "El usuario no es ni propietario ni encargado!!";
            $retorno->exito = false;
            $newResponse = $response->withJson($retorno, 409);
        }
        return $newResponse;
    }

     public function VerificarPropietario($request, $response, $next)
    {
        $token = null;
        if($request->IsGet())
        {
            $token = $_GET["token"];
        }
        else
        {
            $token = $request->getParsedBody()["token"];
        }
        $obj = Usuario::VerificarJWT($token);

        $usuario = $obj->payload;
        
        if($usuario->perfil == "propietario" || $usuario->perfil=="Propietario")
        {
            $newResponse = $next($request, $response);
        }
        else
        {
            $retorno = new StdClass();
            $retorno->mensaje = "El usuario no es un propietario!!";
            $retorno->exito=false;
            $newResponse = $response->withJson($retorno, 409);
        }

        return $newResponse;
    }

    public function VerificarEncargado($request, $response, $next)
    {
        $token = null;
        if($request->IsGet())
        {
            $token = $_GET["token"];
        }
        else
        {
            $token = $request->getParsedBody()["token"];
        }
        $obj = Usuario::VerificarJWT($token);
        $usuario = $obj->payload;
        
        if($usuario->perfil == "encargado" || $usuario->perfil=="Encargado")
        {
            $newResponse = $next($request, $response);
        }
        else
        {
            $retorno = new StdClass();
            $retorno->mensaje = "El usuario no es un propietario!!";
            $newResponse = $response->withJson($retorno, 409);
        }
        return $newResponse;
    }


    public function MostrarMediasMenosId($request, $response, $next)
    {
        $mediaAux  = new Media();
        
        $listadoMedias = $mediaAux->TraerTodasLasMediasBD();

        $grilla = '<table class="table" border="1" align="center">
        <thead>
            <tr>
                <th>  COLOR </th>
                <th>  MARCA </th>
                <th>  PRECIO    </th>
                <th>  TALLE       </th>
            </tr> 
        </thead>';  

        foreach($listadoMedias as $mediecitas)
        {
            $grilla .= "<tr>
            <td>".$mediecitas->color."</td>
            <td>".$mediecitas->marca."</td>
            <td>".$mediecitas->precio."</td>
            <td>".$mediecitas->talle."</td>
            </tr>";
        }

        $grilla.="</table>";

        $response->getBody()->write($grilla);
        return $response;
    }

    public function MostrarColoresDistintos($request, $response, $next)
    {
        $coloresTemp = array();
        $objRetorno = new stdClass();
        $auxMedia = new Media();
        $medias = $auxMedia->TraerTodasLasMediasBD();
        foreach ($medias as $media) {
            array_push($coloresTemp, $media->color);
        }
        $objRetorno->colores = array_unique($coloresTemp);
        $objRetorno->cantidad = sizeof($objRetorno->colores);
        $newResponse = $response->withJson($objRetorno, 200);  
        return $newResponse;
    }

    public static function MostrarPorID($request, $response, $next)
    {
        $id = null;
        var_dump($next);die();
        if(isset($args["id"]))
        {
            $id = $args["id"];
        }
        $noSeEncontro = true;
        $auxMedia = new Media();
        $medias = $auxMedia->TraerTodasLasMediasBD();  
        if($id != null)
        {
            foreach ($medias as $media) {
                if($media->id == $id)
                {
                    $newResponse = $response->withJson($media, 200);
                    $noSeEncontro = false;
                    break;
                }
            }
            if($noSeEncontro)
            {
                $obj = new stdClass();
                $obj->mensaje = "No se encontro el ID";
                $newResponse = $response->withJson($obj, 409); 
            }
        }
        else
        {
            $newResponse = $response->withJson($medias, 200);
        }
        return $newResponse;
    }

}


?>