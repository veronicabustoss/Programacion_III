<?php

require_once "./clases/Empleado.php";

$legajo = isset($_POST['legajo']) ? $_POST['legajo'] : NULL;

$perfil = isset($_POST['perfil']) ? $_POST['perfil'] : NULL;

$clave = isset($_POST['clave']) ? $_POST['clave'] : NULL;

$empleado = new Empleado($perfil,$legajo,$clave);

$resultado = $empleado->GuardarEnArchivo();

echo json_encode($resultado);

?>