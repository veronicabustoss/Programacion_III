<?php

$json = isset($_GET['json']) ? $_GET['json'] : NULL;

$decodeo = json_decode($json);

$auxReturn = new stdClass();
$auxReturn->exito = false;
$auxReturn->mensaje = "No hay cookie con ese legajo";

if(isset($_COOKIE[$decodeo->legajo]))
{
    $auxReturn->exito = true;
    $auxReturn->mensaje =  $_COOKIE[$decodeo->legajo];
}

echo json_encode($auxReturn);


?>