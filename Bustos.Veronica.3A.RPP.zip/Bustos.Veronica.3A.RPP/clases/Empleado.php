<?php

class Empleado
{
    private $perfil;
    private $legajo;
    private $clave;

    public function __construct($perfil,$legajo,$clave)
    {
        $this->perfil = $perfil;
        $this->legajo = $legajo;
        $this->clave = $clave;
    }

    public function ToJSON()
    {
        //Retornara una cadena con formato Json
        return '{"perfil":"'.$this->perfil.'","legajo":'.$this->legajo.',"clave":"'.$this->clave.'"}';
    }

    public function GuardarEnArchivo()
    {
        $archivo = fopen("./archivos/empleados.json","a+");
        $claseStd  = new stdClass();
        $claseStd->exito = false;
        $claseStd->mensaje = "No se pudo guardar el empleado.";

        if($archivo!=false)
        {
            //Fijarse si se guarda un objeto de tipo Empleado
          $aux = fwrite($archivo,$this->ToJSON()."\n");  
          if($aux)
          {
            $claseStd->exito = true;
            $claseStd->mensaje = "El empleado se pudo guardar con exito!.";
          }
        }
        fclose($archivo);

        return $claseStd;
   
    }

    public static function TraerTodos()
    {
        //retornara un array de objetos de tipo Ufologo
        $archivo = fopen("./archivos/empleados.json","r");
        $array = array();
        while(!feof($archivo))
        {
            $linea = trim(fgets($archivo));
            if($linea != null)
            {
                $auxJson = json_decode($linea);
                $auxUfologo = new Empleado($auxJson->perfil,$auxJson->legajo,$auxJson->clave);

                array_push($array,$auxUfologo);
            }
        }

        fclose($archivo);

        return $array;
    }

    public static function VerificarExistencia($empleado)
    {
        $todosEmpleados  = Empleado::TraerTodos();

        $stdClass = new stdClass();

        $stdClass->existe = false;
        $stdClass->mensaje = "El empleado no se encuentra en la lista.";

        foreach($todosEmpleados as $auxEmp)
        {
            if($empleado->legajo == $auxEmp->legajo && $empleado->clave == $auxEmp->clave)
            {
                $stdClass->existe = true;
                $stdClass->mensaje = "El empleado si se encuentra en la lista!.";
            break;
            }
        }

        return $stdClass;

    }



}

?>