<?php
require_once "./clases/Empleado.php";

$legajo = isset($_POST['legajo']) ? $_POST['legajo'] : NULL;

$clave = isset($_POST['clave']) ? $_POST['clave'] : NULL;

$auxEmp = new Empleado(null,$legajo,$clave);

$jsonEmp = Empleado::VerificarExistencia($auxEmp);


if($jsonEmp->existe)
{
    $fecha = date("D-m-Y")."_".date("Gis");

    setcookie($legajo,$fecha."-".$jsonEmp->mensaje);

    header('location:ListadoEmpleados.php');
}
else
{
    $retorno = new stdClass();
    $retorno->exito = false;
    $retorno->mensaje = $jsonEmp->mensaje;
    echo json_encode($retorno);
}


?>