<?php
include "FuncionEjer_19.php";

class Rectangulo extends FiguraGeometrica
{
    private $_ladoDos;
    private $_ladoUno;

    public function __construct($ladoUno,$ladoDos)
    {
        parent::__construct();
        $this->_ladoDos = $ladoDos;
        $this->_ladoUno = $ladoUno;
    }

    protected function CalcularDatos()
    {

    } 

    
}

class Triangulo extends FiguraGeometrica
{

}

?>