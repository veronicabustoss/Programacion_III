<?php
echo 'Hola ';//No se puede con enter separar por renglones
echo 'Mundo';
$nombre = "veronica";
$apellido = "bustos";
echo "<br>";
echo  ucfirst($apellido)," ", ucfirst($nombre); //El ucfirst combierte el primer caracter del string en mayusula


?>