<?php
$numeros = array(0,0,0,0,0);

$contador = 0;
$promedio = 0;
for($i = 0; $i <5; $i ++)
{
    $numeros[$i] = rand(1,10);  
    $contador += $numeros[$i];
}
$promedio = $contador / 5;

if($promedio > 6)
{
    echo "El promedio ", $promedio, " es mayor a 6", "<br>";
}
else if($promedio < 6 )
{
    echo "El promedio ", $promedio, " es menor a 6", "<br>";
}
else
{
    echo "El promedio ", $promedio, " es igual a 6", "<br>";
}

var_dump($numeros);
/*
for($i = 0; $i <5; $i ++)
{
    array_push($numeros,rand(1,100)); //Me agrega un elemento al final del array
}*/

?>