<?php
$x = 2;
for($i = 1 ; $i <=10 ; $i ++ )
{
    echo $x, "x" , $i ," = ", $x * $i , "<br>";
}

?>